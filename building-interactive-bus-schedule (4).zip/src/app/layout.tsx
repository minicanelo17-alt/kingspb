import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Маршрут 842 — Кингисепп ⇄ Санкт-Петербург | АТП Ивангород",
  description:
    "Актуальное интерактивное расписание автобусов маршрута 842 Кингисепп — Санкт-Петербург. Ближайшие рейсы, отмены, объявления, контакты диспетчерской.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="text-slate-900 antialiased">{children}</body>
    </html>
  );
}
