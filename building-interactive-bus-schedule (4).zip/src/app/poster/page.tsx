"use client";

import { useEffect, useState } from "react";
import QRCode from "react-qr-code";

interface PosterInfo {
  number: string;
  fromCity: string;
  toCity: string;
  dispatcherPhone: string;
}

export default function PosterPage() {
  const [origin, setOrigin] = useState("");
  const [copied, setCopied] = useState(false);
  const [info, setInfo] = useState<PosterInfo | null>(null);

  useEffect(() => {
    setOrigin(window.location.origin);
    fetch("/api/schedule", { cache: "no-store" })
      .then((r) => r.json())
      .then((j) => {
        if (j.route) {
          setInfo({
            number: j.route.number,
            fromCity: j.route.fromCity,
            toCity: j.route.toCity,
            dispatcherPhone: j.route.dispatcherPhone,
          });
        }
      })
      .catch(() => {});
  }, []);

  const url = origin ? `${origin}/` : "";

  const copy = async () => {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt("Скопируйте ссылку:", url);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f26] px-3 py-6 sm:py-10 print:bg-white print:p-0">
      <div className="no-print mx-auto mb-4 flex w-full max-w-xl flex-wrap items-center justify-center gap-2">
        <button
          onClick={() => window.print()}
          className="rounded-xl bg-white px-4 py-2 text-sm font-black text-[#16295e] shadow hover:bg-sky-100"
        >
          🖨 Распечатать плакат
        </button>
        <button
          onClick={copy}
          className="rounded-xl bg-white px-4 py-2 text-sm font-black text-[#16295e] shadow hover:bg-sky-100"
        >
          {copied ? "✓ Ссылка скопирована" : "⧉ Скопировать ссылку"}
        </button>
        <a href="/" className="rounded-xl bg-white/15 px-4 py-2 text-sm font-black text-white hover:bg-white/25">
          ← К расписанию
        </a>
      </div>

      <div className="mx-auto w-full max-w-xl overflow-hidden rounded-3xl bg-white shadow-2xl print:rounded-none print:shadow-none">
        <div className="bg-[#16295e] px-6 py-5 text-center text-white">
          <div className="text-xs font-black tracking-[0.25em] text-sky-200 uppercase">
            АТП Ивангород • Маршрут {info?.number || "842"}
          </div>
          <div className="font-display mt-1 text-xl font-black sm:text-2xl">
            {info?.fromCity || "КИНГИСЕПП"} ⇄ {info?.toCity || "САНКТ-ПЕТЕРБУРГ"}
          </div>
          <div className="mt-1 text-sm text-sky-200">Актуальное расписание — всегда под рукой</div>
        </div>

        <div className="px-6 py-6 text-center">
          <div className="mx-auto w-fit rounded-3xl border-4 border-[#16295e] p-4">
            {url ? (
              <QRCode value={url} size={220} style={{ height: "auto", width: "100%", maxWidth: 220 }} />
            ) : (
              <div className="h-[220px] w-[220px] animate-pulse rounded-xl bg-slate-100" />
            )}
          </div>
          <div className="font-display mt-4 text-xl font-black text-[#16295e]">НАВЕДИТЕ КАМЕРУ</div>
          <div className="mt-1 text-sm font-bold text-slate-600">
            Откроется живое расписание: ближайшие рейсы,
            <br />
            отмены и объявления
          </div>
          <div className="mt-3 rounded-xl bg-slate-100 px-3 py-2 font-mono text-xs font-bold break-all text-[#16295e]">
            {url || "Загружаем адрес…"}
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl bg-sky-50 p-2">
              <div className="text-xl">📷</div>
              <div className="text-[11px] font-black text-[#16295e]">1. Наведи камеру</div>
            </div>
            <div className="rounded-xl bg-sky-50 p-2">
              <div className="text-xl">👆</div>
              <div className="text-[11px] font-black text-[#16295e]">2. Нажми ссылку</div>
            </div>
            <div className="rounded-xl bg-sky-50 p-2">
              <div className="text-xl">🚌</div>
              <div className="text-[11px] font-black text-[#16295e]">3. Смотри рейсы</div>
            </div>
          </div>
        </div>

        <div className="bg-[#16295e] px-6 py-3 text-center text-xs font-bold text-sky-200">
          Диспетчерская: {info?.dispatcherPhone || "+7 931 953 01 02"} • Расписание обновляется автоматически
        </div>
      </div>

      <p className="no-print mx-auto mt-3 max-w-xl text-center text-xs text-sky-200">
        Совет: распечатайте и повесьте на остановках в Кингисеппе и у метро. Пассажиры сканируют код и всегда видят
        актуальное время.
      </p>
    </div>
  );
}
